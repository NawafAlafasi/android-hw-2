package com.example.gradecalc;

        import androidx.appcompat.app.AppCompatActivity;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.example.gradecalc.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x = findViewById(R.id.editText1);
        final EditText y = findViewById(R.id.editText2);
        final EditText z = findViewById(R.id.editText3);
        final EditText v = findViewById(R.id.editText4);
        final TextView result = findViewById(R.id.textview5);

        final TextView uno = findViewById(R.id.textview5);
        final EditText deux = findViewById(R.id.editText1);
        final EditText tres = findViewById(R.id.editText2);
        final EditText qautorze = findViewById(R.id.editText3);
        final EditText cinq = findViewById(R.id.editText4);

        Button add = findViewById(R.id.button);
        Button reset = findViewById(R.id.button1);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(x.getText().toString());
                int b = Integer.parseInt(y.getText().toString());
                int c = Integer.parseInt(z.getText().toString());
                int d = Integer.parseInt(v.getText().toString());
                int addd = a + b + c + d ;
                Toast.makeText(MainActivity.this, addd + "", Toast.LENGTH_SHORT).show();
                result.setText(addd + "");

            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uno.setText("Result");
                deux.setText("");
                tres.setText("");
                qautorze.setText("");
                cinq.setText("");
            }
        });
    }
}